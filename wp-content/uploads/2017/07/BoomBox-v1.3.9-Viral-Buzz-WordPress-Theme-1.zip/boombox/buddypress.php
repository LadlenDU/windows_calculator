<?php

get_header();

the_post();

the_content();

get_footer();