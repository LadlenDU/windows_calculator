=== Boombox ===
Author: Px-lab
Author URI: http://px-lab.com
Requires at least: WordPress 4.1
Tested up to: WordPress 4.5.2
Theme URI: http://themeforest.net/user/px-lab
Version: 1.0.0
License: GNU General Public License v2.0
License URI: http://www.gnu.org/licenses/gpl-2.0.html
Tags: light, one-column, two-columns, three-columns, left-sidebar, right-sidebar, flexible-header, fluid-layout, responsive-layout, blavatar, custom-colors, custom-header, custom-menu, editor-style, featured-images, featured-image-header, post-formats, sticky-post, theme-options, translation-ready, photoblogging


== Description ==
Boombox is most powerful and flexible viral and buzz style WordPress theme. Flexible and fully customizable viral magazine theme combined with most powerful Viral content plugin with a ton of snacks and exclusive features and all that packed with dozens of powerful and popular plugins and with top-notch design.

For more information about Boombox please go to px-lab.com

== Installation ==

Please see installation guide in Documentation.
